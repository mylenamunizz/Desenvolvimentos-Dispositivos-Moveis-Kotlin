package br.unisanta.appduastelas.model

data class Livro(
    val tituloLivro:String,
    val nomeAutor: String
)
