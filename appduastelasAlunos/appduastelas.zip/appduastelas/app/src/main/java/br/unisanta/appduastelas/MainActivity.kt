package br.unisanta.appduastelas

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import br.unisanta.appduastelas.model.Produto
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity(R.layout.activity_main) {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets


        }
        //tela inicial de cadastro de produto
        val edtNome = findViewById<EditText>(R.id.edt_nome_produto)
        val edtPreco = findViewById<EditText>(R.id.edt_preco_produto)
        val btnCadastrar = findViewById<Button>(R.id.btn_cadastrar)
        val fabMostra = findViewById<FloatingActionButton>(R.id.fab_mostra)
        var prod = Produto("",  0.0)
        btnCadastrar.setOnClickListener{
            val nome = edtNome.text.toString()
            val preco = edtPreco.text.toString().toDouble()
            prod = Produto(nome, preco)

            //mensagem de confirmação do cadastro
            val builder = AlertDialog.Builder(this)
            builder.setTitle("Sucesso")
            builder.setMessage("Cadastro OK!")
            val dialog = builder.create()
            dialog.show()
            edtNome.text.clear()
            edtPreco.text.clear()
    }
        //botao que leva pra outra tela
        fabMostra.setOnClickListener{
            val intent = Intent(this, ProdutoActivity::class.java)
            intent.putExtra("produto", prod.toString())
            startActivity(intent)
        }


    }
}