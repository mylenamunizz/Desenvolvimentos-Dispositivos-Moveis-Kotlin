package br.unisanta.appduastelas.model

data class Produto(
    val nomeProduto:String,
    val precoProduto:Double
)
